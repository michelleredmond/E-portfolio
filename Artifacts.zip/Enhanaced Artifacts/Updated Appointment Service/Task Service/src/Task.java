import java.util.Comparator;

/**import java.util.Comparator;
 */

/**
 * @author michelleredmo_snhu
 *
 */
public class Task {
	
	public enum compareById {

	}
	//private access modifier for encapsulation
    private String id;
    private String name;
    private String description;
    private String priority;

    //public constructor of Task object
    public Task(String string, String string2, String string3, String string4, String string5) {}

    //public constructor of Task object accepting 1 String parameter
    public Task(String id) {
        this.id = id;
    }

    //public constructor of Task object accepting 2 String parameters
    public Task(String id, String name) {
        this.id = id;
    }

    //public constructor of Task object accepting 3 String parameters
    public Task(String id, String name, String description) {
        this.id = id;
        this.name = name;
        this.description = description;
        this.priority = "Pending";
        this.priority = "Low";
     

    }

    //public getters to get the value of private variable
    public String getId() {
        return id;
    }

    //public setters to set the value of private variable
    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    
    // Remove the duplicate method declaration
    /**
     * 
     * @param obj
     * @return true | false
     * 
     * check the equality of two Task object
     * return true if both object are equal
     * return false if passed Object is null
     * return false if getClass() method is not equal
     * return true if id of both object are equal otherwise false
     */
    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;

        if (obj == null)
            return false;

        if (this.getClass() != obj.getClass())
            return false;

        Task t = (Task) obj;
        return getId().equals(t.getId());
    }

    /**
     * use Comparator interface
     * override the compare method comparing the id variable of two Task object
     */
    public static Comparator<Task> compareById = new Comparator<Task>() {
        public int compare(Task t1, Task t2) {
            return t1.getId().compareTo(t2.getId());
        }
    };

    /**
     * @return String data type concatenated String value of Task object
     * displaying the id, name, description, status and priority of Task object
     */
    @Override
    public String toString() {
        return "Task [id=" + id + ", name=" + name + ", description=" + description + ", status=" + priority
                + ", priority=" + priority + "]";
    }

    public String getDate() {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'getDate'");
    }

    public String getStatus() {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'getStatus'");
    }

    public String getPriority() {
        return description;
        // TODO Auto-generated method stub
    }

    public String getLocation() {
        return description;
        
        // TODO Auto-generated method stub
    }

    public void setLocation(String location) {
        // TODO Auto-generated method stub

    }

    public void setStatus(String status) {
        // TODO Auto-generated method stub
    }

    public void setPriority(String priority) {
        // TODO Auto-generated method stub
    }

    public void setDate(String date) {
        // TODO Auto-generated method stub
    }
}


