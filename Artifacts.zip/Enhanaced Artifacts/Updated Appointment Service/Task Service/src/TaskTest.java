import org.junit.jupiter.api.Test;


/**
 * 
 */

/**
 * @author michelleredmo_snhu
 *
 */
class TaskTest {

	@Test
	void test() {
		
		      Task task = new Task("0000000001", "Reading", "Read Novel Book");
		      System.out.println(task);
		      System.out.println("ID: " + task.getId());
		      System.out.println("Name: " + task.getName());
		      System.out.println("Description: " + task.getDescription());
		      System.out.println("Status: " + task.getStatus());
			  System.out.println("Date: " + task.getDate());
		      
		      Task task2 = new Task("0000000002", "Writing", "Write a Novel Book");
		      System.out.println(task2);
		      System.out.println("ID: " + task2.getId());
		      System.out.println("Name: " + task2.getName());
		      System.out.println("Description: " + task2.getDescription());
		      System.out.println("Status: " + task2.getStatus());}
			  



		   

		
		
	}


