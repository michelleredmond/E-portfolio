import java.util.Comparator;

/**
 * 
 * Appointment class
 * 
 * Appointment class is a blueprint for Appointment object
 * 
 * Appointment object is a representation of a single Appointment
 * 
 * Appointment object has 3 private variables
 * 
 * Appointment object has 3 public getters and setters
 * 
 * Appointment object has 1 public constructor
 * 
 * Appointment object has 1 public equals method
 * 
 * Appointment object has 1 public toString method
 * 
 * Appointment object has 1 public compareById method
 * 
 */




public class Appointment {

	// private access modifier for encapsulation
	private String id;

	private String name;

	private String description;

	private String date;
	
	private String status;
	
	private String priority; 
	
	private String location;
	
	private String contact;
	

	

	// public constructor of Appointment object accepting 3 String parameters

	public Appointment(String id, String name, String description) {

		this.id = id;

		this.name = name;

		this.description = description;

		this .date = "";

		this .status = "";

		this .priority = "";

		this .location = "";

		this .contact = "";

}

	// public getters to get the value of private variable

	public String getId() {

		return id;

	}

	// public setters to set the value of private variable

	public void setId(String id) {

		this.id = id;

	}

	public String getName() {

		return name;

	}

	public void setName(String name) {

		this.name = name;

	}

	public String getDescription() {

		return description;

	}

	public void setDescription(String description) {

		this.description = description;

	}

	public String getDate() {
		
		return date;

	}

	public void setDate(String date) {
		
		this.date = date;

	}

	public String getStatus() {
		
		return status;

	}

	public void setStatus(String status) {
		
		this.status = status;

	}

	public String getPriority() {
		
		return priority;

	}

	public void setPriority(String priority) {
		
		this.priority = priority;

	}

	public String getLocation() {
		
		return location;

	}

	public void setLocation(String location) {
		
		this.location = location;

	}

	public String getContact() {
		
		return contact;

	}

	public void setContact(String contact) {
		
		this.contact = contact;

	}

	/**
	 * 
	 * @param Appointment object
	 * 
	 * @return int value of the index of the Appointment object in the List
	 * 
	 *         if Appointment object is not found, return -1
	 * 
	 *
	}
	}
	}
	}
	}
	}
	}
	}
	}
	}

		/**
	 * Check if the current appointment object is equal to another object.
	 *
	 * @param  obj	the object to compare to
	 * @return     	true if the objects are equal, false otherwise
	 */
	@SuppressWarnings("null")
	@Override

	public boolean equals(Object obj) {

		if (this == obj)

			return true;

		if (obj == null)

			return false;

		if (this.getClass() != obj.getClass())

			return false;

		@SuppressWarnings("unused")
		Appointment a = (Appointment) obj;

		Appointment t = null;
		return getId().equals(t.getId());

	}

	/**
	 * 
	 * use Comparator interface
	 * 
	 * override the compare method comparing the id variable of two Appointment
	 * object
	 * 
	 */

	public static Comparator<Appointment> compareById = new Comparator<Appointment>() {

		@Override

		public int compare(Appointment a1, Appointment a2) {

			return a1.getId().compareTo(a2.getId());

		}

	};

	/**
	 * 
	 * @return String data type concatenated String value of Appointment object
	 * 
	 *         displaying the id, name and description
	 * 
	 */

	@Override

	public String toString() {

		return "Appointment ID: " + getId() + "\nName: " + getName() + "\nDescription: " + getDescription() + "\n";

	}
}
