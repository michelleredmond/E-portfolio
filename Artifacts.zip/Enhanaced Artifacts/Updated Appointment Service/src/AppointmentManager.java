import java.util.List;

public class AppointmentManager {

    public List<String> alertUpcomingTasks() {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'alertUpcomingTasks'");
    }

    public boolean addAppointment(Appointment appointment4) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'addAppointment'");
    }

}
