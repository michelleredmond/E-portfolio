import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import static org.junit.Assert.*;

import org.junit.Before;



public class AppointmentTestTest{ 
	
	@Test public void createValidAppointmentData() {

		 Appointment Appointment = new Appointment("0000000001", "Reading", "Read Novel Book");

		System.out.println(Appointment);

		System.out.println("ID: " + Appointment.getId());

		System.out.println("Name: " + Appointment.getName());

		System.out.println("Description: " + Appointment.getDescription());

		System.out.println("Status: " + Appointment.getStatus());

		System.out.println("Date: " + Appointment.getDate());
	}

	@Test public void invalidID() {

		Appointment Appointment = new Appointment("0000000002x", "Playing", "Playstation 5");

		System.out.println(Appointment);

		System.out.println("size: " + Appointment.getStatus());

	}

	@Test public void invalidName() {
		
		Appointment Appointment = new Appointment("0000000002", "Playing Playing Playing Playing Playing Playing Playing", "Playstation 5");

		System.out.println(Appointment);

		System.out.println("size: " + Appointment.getStatus());
	}

	@Test public void invalidDescription() {
		
		Appointment Appointment = new Appointment("0000000002", "Playing", "Playstation 5 Playstation 5 Playstation 5 Playstation 5 Playstation 5 Playstation 5");

		System.out.println(Appointment);

		System.out.println("size: " + Appointment.getStatus());
	}

	@Test public void invalidDate() {
		
		Appointment Appointment = new Appointment("0000000002", "Playing", "Playstation 5");

		System.out.println(Appointment);

		System.out.println("size: " + Appointment.getStatus());
	}

	@Test public void invalidStatus() {
		
		Appointment Appointment = new Appointment("0000000002", "Playing", "Playstation 5");

		System.out.println(Appointment);

		System.out.println("size: " + Appointment.getStatus());
	}

	@Test public void existingID() {
		
		Appointment Appointment = new Appointment("0000000001", "Reading", "Read Novel Book");

		System.out.println(Appointment);

		System.out.println("size: " + Appointment.getStatus());
	}

	@Test public void updateAppointment() {
		
		Appointment Appointment = new Appointment("0000000001", "Singing", "Wedding Engagement");

		update(Appointment);

		System.out.println("Updated: " + Appointment);

		System.out.println("object: " + Appointment.getStatus());
	}

	private void update(Appointment appointment) {
		// TODO: Implement the update logic here	

	}

	@Test public void deleteAppointment() {
		
		Appointment Appointment = new Appointment("0000000001", "Singing", "Wedding Engagement");

		delete(Appointment);

		System.out.println("Deleted: " + Appointment);

		System.out.println("object: " + Appointment.getStatus());
	}

	private void delete(Appointment appointment) {
		// TODO: Implement the delete logic here

	}

}
	

	


