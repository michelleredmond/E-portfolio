import static org.junit.jupiter.api.Assertions.*;

import java.util.Collections;

import java.util.List;

import org.junit.jupiter.api.Test;

import org.junit.Assert;

import java.util.ArrayList;

import org.junit.Before;

public class AppointmentServiceTest {
		// Other methods...
	
		@Test
		public void testValidAppointmentData() {
			Appointment task = new Appointment("0000000001", "Reading", "Read Novel Book");
			addAppointment(task);
			System.out.println("New Appointment: " + task);
			
		}
	

	

	@Test public void addAppointment(Appointment task) {
		// TODO Auto-generated method stub
		throw new UnsupportedOperationException("Unimplemented method 'addAppointment'");
	}

	@Test public void invalidID() {

	Appointment Appointment = new Appointment("0000000002x", "Playing", "Playstation 5");

	addAppointment(Appointment);

	System.out.println("size: " + Appointment.getStatus());
	}

	@Test public void invalidName() {

	Appointment Appointment = new Appointment("0000000002", "Playing Playing Playing Playing Playing Playing Playing", "Playstation 5");

	addAppointment(Appointment);

	System.out.println("size: " + Appointment.getStatus());

	}

	@Test public void invalidDescription() {

	Appointment Appointment = new Appointment("0000000002", "Playing", "Playstation 5 Playstation 5 Playstation 5 Playstation 5 Playstation 5 Playstation 5");

	addAppointment(Appointment);

	System.out.println("size: " + Appointment.getStatus());

	}

	@Test public void existingID() {

	Appointment Appointment = new Appointment("0000000001", "Reading", "Read Novel Book");

	addAppointment(Appointment);

	System.out.println("size: " + Appointment.getStatus());

	}

	@Test public void updateAppointment() {

		Appointment Appointment = new Appointment("0000000001", "Singing", "Wedding Engagement");

		update(Appointment);

		System.out.println("Updated: " + Appointment);

		System.out.println("object: " + Appointment.getStatus());
	}

	private void update(Appointment appointment) {
		// TODO: Implement the update logic here
	}

	@Test public void deleteAppointment() {

	Appointment Appointment = new Appointment("0000000001", "Singing", "Wedding Engagement");

	System.out.println("Deleted: " + Appointment);
	}

		@Test public void upcomingAndPastAppointments() {
			upcomingAndPastAppointments();
			System.out.println("object: " + Appointments);
		}

		@Test public void allAppointment() {
			allAppointments();
		}

		@Test public void validateID() {
			validateID();
		}

		@Test public void validateName() {
			validateName();
		}

		@Test public void validateDescription() {
			validateDescription();
		}

		@Test public void validateDate() {
			validateDate();
		}

		@Test public void validateStatus() {
			validateStatus();
		}
		
		@Test public void validatePriority() {
			validatePriority();
		}

		@Test public void validateLocation() {
			validateLocation();
		}

		@Test public void validateContact() {
			validateContact();
		}

		@Test public void validateNotes() {
			validateNotes();
		}

		@Test public void validateAll() {
			validateAll();
		}

	/**

	*

	* @param Appointment

	*

	* update Appointment object if same ID and valid name and description

	*/

	
/**

	*

	* @param Appointment

	* @return integer data type

	*

	* use Collections binary search by Appointment ID

	* return positive integer from 0 to N if ID is found

	* return negative integer if ID is not found

	*/

	

	/**
	 * 	
	 * @param Appointment
	 * @return integer data type
	 * 
	 * use Collections binary search by Appointment ID
	 * return positive integer from 0 to N if ID is found
	 * return negative integer if ID is not found
	 * 
	 */

	List<Appointment> Appointments = new ArrayList<>(); // Declare and initialize the Appointments variable

	public int getIndex2(Appointment Appointment) {
		
		// create new instance of Appointment object and pass the String ID in the constructor, set name and description as empty or null

		// if ID found, return int value as List index (0...N)

		int index = Collections.binarySearch(Appointments, Appointment, Appointment.compareById);

		return index;
	}

	/**

	*


	* @param id

	* @return true or false

	*

	* validate id parameter, if not null and length is less than or equal to 10

	*/

	public boolean validateID(String id) {

	if (id != null && id.length() <= 10)

	return true;

	return false;

	}

	/**

	*

	* @param name

	* @return true or false

	*

	* validate name parameter, if not null and length is less than or equal to 20

	*/

	public boolean validateName(String name) {

	if (name != null && name.length() <= 20)

	return true;

	return false;

	}

	/**

	*

	* @param description

	* @return true or false

	*

	* validate description parameter, if not null and length is less than or equal to 50

	*/

	public boolean validateDescription(String description) {

	if (description != null && description.length() <= 50)

	return true;

	return false;

	}

	/**
	 * 
	 * @return List of Appointment objects
	 * 
	 * return all Appointment objects
	 * 
	 */

	public List<Appointment> upcomingAppointments() {

	//create new List object of Appointment
	List<Appointment> appointmentList = new ArrayList<>();

	//iterate through the List of Appointment

	//if appointment date is in the future, add it to the List

	//return List of Appointment objects

	return appointmentList;
	
	}

	

	/**
	 * 
	 * @return List of Appointment objects
	 * 
	 * return all Appointment objects
	 * 
	 */

	public List<Appointment> pastAppointments() {

	//create new List object of Appointment
	List<Appointment> appointmentList = new ArrayList<>();

	//iterate through the List of Appointment

	//if appointment date is in the past, add it to the List

	//return List of Appointment objects

	return appointmentList;


		}

		/**
		 * 
		 * @return List of Appointment objects
		 * 
		 * return all Appointment objects
		 * 
		 */

	/**
	 * 
	 * @return List of Appointment objects
	 * 
	 * return all Appointment objects
	 * 
	 */

	public List<Appointment> allAppointments() {
		
	//create new List object of Appointment
	List<Appointment> appointmentList = new ArrayList<>();

	//iterate through the List of Appointment

	//add it to the List

	//return List of Appointment objects

	return appointmentList;
	
	}



	}






	
	
	

	/**
	 * 
	 * @return List of Appointment objects
	 * 
	 * return all Appointment objects
	 * 
	 */
	