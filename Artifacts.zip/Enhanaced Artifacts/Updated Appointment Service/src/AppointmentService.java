import java.util.ArrayList;

import java.util.Collections;

import java.util.List;

import static java.util.Collections.*;

import java.util.Comparator;




public class AppointmentService<T> {

	// private access modifier for encapsulation

	private List<Appointment> Appointments = new ArrayList<>();

	// private access modifier for encapsulation

	private List<Appointment> upcomingAppointments = new ArrayList<>();

	// private access modifier for encapsulation

	private List<Appointment> pastAppointments = new ArrayList<>();

	// public constructor of AppointmentService object

	
	public void addAppointment(String id, String name, String description) {
		
	}
		// create an instance of Appointment object and pass the String ID in the constructor, set name and description as empty or null

		// if ID found, return int value as List index (0...N)
		/**
		 * Check if the ID is found in the List and return the index if found.
		 *
		 * @param id the ID to search for
		 */
		
		 void findIndex (String id) {
		    int index = Collections.binarySearch(Appointments, new Appointment(id, "", ""), Appointment.compareById);
		    for (int i = 0; i < Appointments.size(); i++) {

		        if (Appointments.get(i).getId().equals(id)) {
		            index = i;
		            
		        return;

		        }
		    }
		}
		
	
		
		
	// public addAppointment method that accept an instance of Appointment
	// object

	// pass the 3 string parameters of unique id, name and description to the
		// create an instance of AppointmentService

		// create an instance of Appointment object and pass the String ID in the

		// constructor, set name and description as empty or null

		// if ID found, return int value as List index (0...N)

		// use Collections binary search by Appointment ID

		// return positive integer from 0 to N if ID is found
/**
 * 
 * @param Appointment - Appointment class containing id, name & description variables
 * @return integer data type
 * 
 * use Collections binary search by Appointment ID
 * return positive integer from 0 to N if ID is found
 * return negative integer if ID is not found
 * 
 */
public int getIndex(Appointment Appointment) {
    int index = Collections.binarySearch(Appointments, Appointment, Appointment.compareById);
    if (index >= 0) {
        return index;
    }
    return -1;
}
	// return negative integer if ID is not found

	// use Collections binary search by Appointment ID

	// return positive integer from 0 to N if ID is found

	// return negative integer if ID is not found

	// use Collections binary search by Appointment ID

	// return positive integer from 0 to N if ID is found


	

	public void display() {
		
		for (Appointment obj : Appointments) {

			System.out.println(obj);

		}

	}

	// return List object of Appointment

	private static List<Appointment> newArrayList() {
		// TODO Auto-generated method stub
		return null;
	}

	/**
	 *
	 * 
	 * 
	 * @param Appointment
	 *            - Appointment class containing id, name & description variables
	 *
	 * 
	 * 
	 *            add Appointment object if List is empty and passed all the field
	 *            validations
	 *
	 * 
	 * 
	 */

	public boolean addAppointment(Appointment Appointment) {
		
		// create an instance of Appointment object and pass the String ID in the
		// constructor, set name and description as empty or null

		// if ID found, return int value as List index (0...N)

		// if ID not found, return negative values

		int index = getIndex(Appointment);

		// validate id if doesn't exist, name & description

		if (index < 0 && validateID(Appointment.getId()) && validateName(Appointment.getName())
				&& validateDescription(Appointment.getDescription())) {

			Appointments.add(Appointment);

			return true;

		}

		return false;

	}

	/**
	 * 	
	 * 	
	 * @param Appointment
	 * 
	 * @return boolean data type
	 * 
	 * use Comparator interface

	 * override the compare method comparing the id variable of two Appointment object
	 * 
	 * 
	 */

	

	
	   
	/**
	 * 
	 * @param Appointment
	 * 
	 * update Appointment object if same ID and valid name and description
	 * 
	 */

	public boolean update(Appointment Appointment) {

		// create an instance of Appointment object and pass the String ID in the
		// constructor, set name and description as empty or null

		// if ID found, return int value as List index (0...N)

		int index = getIndex(Appointment);
		
         // validate id if doesn't exist, name & description

		if (index < 0 && validateID(Appointment.getId()) && validateName(Appointment.getName())
				&& validateDescription(Appointment.getDescription())) {

			Appointments.add(Appointment);

			return true;

		}

		return false;

	}

	/**
	 *
	 * 
	 * 
	 * @param id
	 *
	 * 
	 * 
	 *            delete Appointment object when Appointment ID exist
	 *
	 * 
	 * 
	 */

	public void deleteAppointment(String id) {

		// invoke getIndex(Appointment) method

		// create new instance of Appointment object and pass the String ID in the
		// constructor, set name and description as empty or null

		// if ID found, return int value as List index (0...N)

		int index = getIndex(new Appointment(id, "", ""));

		// check if index is greater than or equal to 0 to prevent
		// ArrayIndexOutOfBoundsException

		if (index >= 0)

			Appointments.remove(index);

	}

	// create  upcoming appointments method

	// return List object of Appointment

	public List<Appointment> upcomingAppointments() {

		// create new List object of Appointment

		List<Appointment> upcomingAppointments = newArrayList();

		// iterate through the List of Appointment

		for (Appointment obj : Appointments) {

			// get the current date

			// get the date of the Appointment object

			// compare the current date and Appointment date

			// if Appointment date is greater than current date, add to the List

			// of upcoming appointments

			// return List object of Appointment

		}

		return upcomingAppointments;

	}




	/**
	 *
	 * 
	 * 
	 * @param Appointment
	 * 
	 * @return integer data type
	 *
	 * 
	 * 
	 *         use Collections binary search by Appointment ID
	 * 
	 *         return positive integer from 0 to N if ID is found
	 * 
	 *         return negative integer if ID is not found
	 * 
	 */

	

	/**
	 *
	 * 
	 * 
	 * @param id
	 * 
	 * @return true or false
	 *
	 * 
	 * 
	 *         validate id parameter, if not null and length is less than or equal
	 *         to 10
	 * 
	 */

	public boolean validateID(String id) {

		if (id != null && id.length() <= 10)

			return true;

		return false;

	}

	/**
	 *
	 * 
	 * 
	 * @param name
	 * 
	 * @return true or false
	 *
	 * 
	 * 
	 *         validate name parameter, if not null and length is less than or equal
	 *         to 20
	 * 
	 */

	public boolean validateName(String name) {

		if (name != null && name.length() <= 20)

			return true;

		return false;

	}

	/**
	 *
	 * 
	 * 
	 * @param description
	 * 
	 * @return true or false
	 *
	 * 
	 * 
	 *         validate description parameter, if not null and length is less than
	 *         or equal to 50
	 * 
	 */

	public boolean validateDescription(String description) {

		if (description != null && description.length() <= 50)

			return true;

		return false;

	}

}
