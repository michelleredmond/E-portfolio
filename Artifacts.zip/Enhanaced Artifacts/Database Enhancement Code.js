// MongoDB Script for QuantigrationUpdate Database
// Author: Michelle Redmond - SNHU
// Date: 2/11/2024
// Description: This script enhances the QuantigrationUpdate database using MongoDB.
// It includes creating a database, auditing and enhancing the schema, advanced querying,
// data mining integration, and UI enhancements for security and performance optimization.

const { MongoClient } = require('mongodb');

// Database Name
const dbName = 'QuantigrationUpdate';

// Connection URL for MongoDB server
const url = 'mongodb://localhost:27017';

// Create a new MongoClient
const client = new MongoClient(url, { useNewUrlParser: true, useUnifiedTopology: true });

// Connect to the MongoDB server
client.connect(function(err) {
    if (err) {
        console.error('Error connecting to MongoDB:', err);
        return;
    }
    console.log('Connected successfully to MongoDB');
    
    // Use the specified database
    const db = client.db(dbName);

    // Audit and enhance current database schema for 'customers' collection
    // These enhancements aim to improve application performance.
    // Create a new collection with the name "customers" and define its schema

    const customerCollection = db.collection('customers');

    // Create a new index in the 'customers' collection to optimize queries
    customerCollection.createIndex(
        { customerID: 1, lastName: 1 },
        { unique: true },
        function(err) {
            if (err) {
                console.error('Error creating index:', err);
                return;
            }
            console.log('Index created successfully on customers collection');
        }
    );

    // More operations to follow...
});
    if (err) {
        console.error('Error connecting to MongoDB:', err);
        return;
    }
    console.log('Connected successfully to MongoDB');
    
    // Use the specified database
    const db = client.db(dbName);

    // Audit and enhance current database schema for 'customers' collection
    // These enhancements aim to improve application performance.
    // Create a new collection with the name "customers" and define its schema

    const customerCollection = db.collection('customers');

    // Create a new index in the 'customers' collection to optimize queries
    customerCollection.createIndex(
        { customerID: 1, lastName: 1 },
        { unique: true },
        function(err) {
            if (err) {
                console.error('Error creating index:', err);
                return;
            }
            console.log('Index created successfully on customers collection');
        }
    );

    // More operations to follow...
// Ensure proper closing of the MongoDB client
process.on('SIGINT', () => {
    client.close();
    console.log('MongoDB client closed');
});

// Additional MongoDB operations and data manipulation can be added below

// Close the MongoDB client
client.close();
console.log('MongoDB client closed');


