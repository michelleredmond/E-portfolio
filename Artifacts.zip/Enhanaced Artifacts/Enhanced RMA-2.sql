-- Enhanced RMA-2 SQL Script
-- Author: Michelle Redmond
-- Contact: michelle.redmond@snhu.edu
-- Course: Algorithms and Data Structures
-- Date: 2024-02-07  Revised on 2/23/2024
-- Description: This script sets up a database and collections for an RMA system. It includes operations such as creating databases, collections, indexes, inserting documents, updating documents, deleting documents, and performing various data manipulations.
-- It includes operations such as creating databases, collections, indexes, inserting documents, updating documents, deleting documents, and performing various data manipulations.
-- and performing various data manipulations.


--Connect to the 'sql server' database to run this snippet
  -- Create a new database called 'RMA_System'
  -- Connect to the 'master' database to run this snippet
  USE master
  GO
  
  CREATE DATABASE RMA_System;
 
-- Create a table for Purchasers 
-- Note: Define appropriate columns and data types as per the requirements.
 create TABLE Purchaser(
    Purchaser_ID INT PRIMARY KEY,
    Purchaser_Name VARCHAR(255),
    Email VARCHAR(255),
    Purchaser_Address VARCHAR(255),
    Phone_number VARCHAR(10),
);

--Insert a new purchaser into document into the Purchasers collection
-- Note: Replace the placeholder values with actual data.
    INSERT INTO Purchaser (Purchaser_ID, Purchaser_Name, Email, Purchaser_Address, Phone_number)
    VALUES ('1', 'John Redmond', '', '123 Main St', '1234567890');  



-- Efficiently find a Purchaser by email using an index crated for PurchaserCollection table 
-- Note: Creating an index on the Email column for faster search.
 CREATE INDEX IDX_Purchaser_Email ON Purchaser(Email);

-- Update a document in the Purchaser collection
-- Modify the Purchaser address for a specific Purchaser
-- Note: Modify the query as per the update requirements.
 UPDATE Purchaser
 SET Purchaser_Address = '456 Elm St'
 WHERE Purchaser_ID = 1;

-- Delete a document from the Purchaser collection
-- Note: Modify the condition to match the document to be deleted.
 DELETE FROM Purchaser
 WHERE Purchaser_ID = 1;


-- Create a new table for Product Inventory collection
-- Note: Define appropriate columns and data types as per the requirements.
CREATE TABLE ProductInventory(
    Product_ID INT PRIMARY KEY,
    Product_Name VARCHAR(255),
    Product_Price DECIMAL(10, 2),
    Product_Description VARCHAR(255),
    
);

-- Insert a new document into the Product Inventory collection
-- Note: Replace the placeholder values with actual data.
 INSERT INTO ProductInventory (Product_ID, Product_Name, Product_Price, Product_Description)
 VALUES ('1', 'Printer', '100.00', 'LaserPrinter');

-- Efficiently find a Product Inventory Collection by name using an index
-- Note: Creating an index on the Name column for faster search.
 CREATE INDEX IDX_Product_Name ON ProductInventory(Product_Name);


-- Update a document in the Product Inventory collection
-- Note: Modify the query as per the update requirements.
 UPDATE ProductInventory
 SET Product_Price  = 150.00
 WHERE Product_ID = 1;

--Create Order Id and Order Date for the OrdersCollection Table
--Note: Replace the placeholder values with actual data.
CREATE TABLE OrdersCollection (
    OrderID INT PRIMARY KEY,
    OrderDate DATE,
    PurchaserID INT,
    ProductID INT,
    -- Add more columns as needed
);


-- Insert a new document into the Orders collection useing the OrderID, OrderDate, PurchaserID, and ProductID
-- Note: Replace the placeholder values with actual data.
 INSERT INTO OrdersCollection (OrderID, OrderDate, PurchaserID, ProductID)
 VALUES (1, '2024.02.07', 1, 1);


--Perform a join operation to retrieve the Purchaser name and product name for a specific order
--Note: Replace the placeholder values with actual data.
 SELECT c.Purchaser_Name, p.Product_Name
 FROM OrdersCollection o
 JOIN Purchaser c ON o.PurchaserID = c.Purchaser_ID
 JOIN ProductInventory p ON o.ProductID = p.Product_ID
 WHERE o.OrderID = 1;


--Perform a join operation to retrieve the products broght by a specific Purchaser
--Note: Replace the placeholder values with actual data.
 SELECT c.Purchaser_Name, p.Product_Name
 FROM OrdersCollection o
 JOIN Purchaser c ON o.PurchaserID = c.Purchaser_ID
 JOIN ProductInventory p ON o.ProductID = p.Product_ID
 WHERE c.Purchaser_ID = 1;
 
 --End of the script